package com.example.csdl_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddOrEditEmployeeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_or_edit_employee);
    }
}